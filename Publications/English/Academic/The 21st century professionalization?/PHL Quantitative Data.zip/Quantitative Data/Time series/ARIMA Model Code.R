library(readxl)
library(forecast)

file_path <- "D:/Documents/Work/Paper/Quantitative Data/Time series/Broadband Access for Adults.xlsx"
data <- read_excel(file_path)

broadband_ts <- ts(data[[3]], start = data$Year[1], frequency = 1)

plot(broadband_ts, main = "Broadband Access for Adults", ylab = "Percentage", xlab = "Year")

ma_model <- auto.arima(broadband_ts, seasonal = FALSE, stepwise = FALSE, approximation = FALSE)

summary(ma_model)

forecasted_values <- forecast(ma_model, h = 5)

plot(forecasted_values, main = "Broadband Access Forecast", ylab = "Percentage", xlab = "Year")

forecasted_mean <- forecasted_values$mean
print(forecasted_mean)

forecasted_lower <- forecasted_values$lower
forecasted_upper <- forecasted_values$upper

print(forecasted_lower)
print(forecasted_upper)