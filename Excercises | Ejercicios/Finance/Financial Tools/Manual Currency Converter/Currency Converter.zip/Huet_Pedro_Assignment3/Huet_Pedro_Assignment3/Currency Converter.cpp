#include "Currency.h"

Currency::Currency(const std::string& symbol, double exchangeRate) : symbol_(symbol), exchange_rate_(exchangeRate) {}

double Currency::convertToUSD(double amount) const {
    return amount / exchange_rate_;
}

double Currency::convertFromUSD(double amount) const {
    return amount * exchange_rate_;
}

std::string Currency::getCurrencySymbol() const {
    return symbol_;
}

double Currency::getExchangeRate() const {
    return exchange_rate_;
}