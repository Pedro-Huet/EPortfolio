#include "Currency.h"
#include <iostream>
#include <map>
#include <memory>

int main() {
    std::map<std::string, std::shared_ptr<Currency>> currencies_; // Change 1 (#4) : Incorporate maps to associate and store currency values
                                                                 // Shared pointers are also in place
    currencies_["USD"] = std::make_shared<Currency>("USD", 1.0);
    currencies_["EUR"] = std::make_shared<Currency>("EUR", 0.9494);
    currencies_["GBP"] = std::make_shared<Currency>("GBP", 0.7925);
    currencies_["JPY"] = std::make_shared<Currency>("JPY", 110.52);
    currencies_["AUD"] = std::make_shared<Currency>("AUD", 1.3125);
    currencies_["CAD"] = std::make_shared<Currency>("CAD", 1.2571);
    currencies_["MXN"] = std::make_shared<Currency>("MXN", 19.9375);

    while (true) {
        std::cout << "Enter base currency symbol (USD, EUR, GBP, JPY, AUD, CAD, MXN): ";
        std::string baseCurrencySymbol;
        std::cin >> baseCurrencySymbol;

        auto baseCurrencyIter = currencies_.find(baseCurrencySymbol); // Change 2 (#3): Incorporate iterators to check for currency symbols
        if (baseCurrencyIter == currencies_.end()) {
            std::cout << "Invalid base currency symbol. Please try again." << std::endl;
            continue;
        }
        std::shared_ptr<Currency> baseCurrency = baseCurrencyIter->second; // Change 3 (#7): Incorporate shared pointers to easily find symbols

        std::cout << "Enter transaction currency symbol (USD, EUR, GBP, JPY, AUD, CAD, MXN): ";
        std::string foreignCurrencySymbol;
        std::cin >> foreignCurrencySymbol;

        auto foreignCurrencyIter = currencies_.find(foreignCurrencySymbol); // Iterators have been added
        if (foreignCurrencyIter == currencies_.end()) {
            std::cout << "Invalid transaction currency symbol. Please try again." << std::endl;
            continue;
        }
        std::shared_ptr<Currency> foreignCurrency = foreignCurrencyIter->second; // Shared pointers have been added

        std::cout << "Enter amount in base currency (input a numeric value): ";
        double amount;
        std::cin >> amount;

        double usdAmount = baseCurrency->convertToUSD(amount);
        double resultAmount = foreignCurrency->convertFromUSD(usdAmount);

        std::cout << "Converted amount: " << resultAmount << " " << foreignCurrency->getCurrencySymbol() << std::endl;

        std::cout << "Do you want to perform another conversion? (1 = Yes / 0 = No): ";
        int choice;
        std::cin >> choice;

        if (choice == 0) {
            break;
        }
    }

    std::cout << "Enjoy your new currency!" << std::endl;

    return 0;
}