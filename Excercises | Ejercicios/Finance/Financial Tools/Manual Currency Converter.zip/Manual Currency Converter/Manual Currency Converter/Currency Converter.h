#ifndef Currency_Converter_h
#define Currency_Converter_h

#include <string>

class Currency {
public:
    Currency(const std::string& symbol, double exchangeRate);
    double convertToUSD(double amount) const;
    double convertFromUSD(double amount) const;
    std::string getCurrencySymbol() const;
    double getExchangeRate() const;
    ~Currency() = default;

private:
    std::string symbol_;
    double exchange_rate_;
};

#endif // Currency_Converter_h